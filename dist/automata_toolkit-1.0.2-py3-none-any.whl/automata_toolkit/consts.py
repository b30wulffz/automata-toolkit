class Consts():
    EPSILON = "$"